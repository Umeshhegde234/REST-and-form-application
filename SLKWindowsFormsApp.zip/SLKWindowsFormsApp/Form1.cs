﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SLKWindowsFormsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Size = new System.Drawing.Size(900, 126);
            ResponseData responseData = new ResponseData();

            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri("https://localhost:44367/SLK/GetWeekDayDetails/1");


                    var postTask = client.GetAsync(client.BaseAddress);
                    //postTask.Wait();
                    var result = postTask.Result;
                    string res = "";
                    using (HttpContent content = result.Content)
                    {
                        Task<string> resultjson = content.ReadAsStringAsync();
                        res = resultjson.Result;

                        label1.Text = res;


                        responseData = JsonConvert.DeserializeObject<ResponseData>(res);
                        //(int)result.StatusCode;
                    }

                    foreach (data item in responseData.Days)
                    {
                        comboBox1.Items.Add(item.Day);
                    }
                    foreach (CurrentTime item in responseData.TimeOfTheDay)
                    {
                        comboBox2.Items.Add(item.TimeOfDay);
                    }
                    
                    //comboBox1.DataSource = responseData.TimeOfTheDay;
                    //comboBox1.DataSource = responseData;

                    //comboBox1.Items.Add(responseData.Days);
                    //comboBox1.Items.Add(responseData.TimeOfTheDay);
                }
                catch (TaskCanceledException ex)
                {

                }

            }
        }



        public class ResponseData
        {
            public List<data> Days { get; set; }
            public bool URLParameter { get; set; }
            public List<CurrentTime> TimeOfTheDay { get; set; }
        }
        public class data
        {
            public string Day { get; set; }
        }

        public class CurrentTime
        {
            public string TimeOfDay { get; set; }
        }



        public class RequestPayload
        {
            public List<DateRequest> dateRequests { get; set; }
        }

        public class DateRequest
        {
            public string Dates { get; set; }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RequestPayload requestPayload = new RequestPayload();
            List<DateRequest> lstDateRequest = new List<DateRequest>();
            foreach (string item in comboBox1.Items)
            {
                DateRequest dateRequest = new DateRequest();

                dateRequest.Dates = item;
                lstDateRequest.Add(dateRequest);
            }
            requestPayload.dateRequests = lstDateRequest;

            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri("https://localhost:44367/SLK/PostWeekDayDetails/1");

                    string requestContent = JsonConvert.SerializeObject(requestPayload);

                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress);
                    request.Content = new StringContent(requestContent, Encoding.UTF8, "application/json");//CONTENT-TYPE header

                    var postTask = client.SendAsync(request);


                    //var postTask = client.PostAsJsonAsync("PostWeekDayDetails", requestPayload);
                    //postTask.Wait();
                    var result = postTask.Result;
                    string res = "";
                    using (HttpContent content = result.Content)
                    {
                        Task<string> resultjson = content.ReadAsStringAsync();
                        res = resultjson.Result;
                        label2.Text = res;
                        
                        //response = JsonConvert.DeserializeObject<object>(res);
                        //(int)result.StatusCode;
                    }

                }
                catch (TaskCanceledException ex)
                {

                }

            }


        }
    }
}
