﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;

namespace WeekdayProject.Controllers
{
    public class WeekdayGetController : ApiController
    {


        public class ResponseData
        {
            public List<data> Days { get; set; }
            public bool URLParameter { get; set; }
            public List<CurrentTime> TimeOfTheDay { get; set; }
        }
        public class data
        {
            public string Day { get; set; }
        }

        public class CurrentTime 
        {
            public string TimeOfDay { get; set; }
        }


        //Get method
        [HttpGet]
        [Route("SLK/GetWeekDayDetails/{optionalParameter?}")]
        public HttpResponseMessage GetWeekDayDetails([FromUri] string optionalParameter = null)
        {
            HttpResponseMessage httpResponseMessage = new HttpResponseMessage();
            List<data> lstData = new List<data>();
            ResponseData responseData = new ResponseData();
            try
            {
                responseData.URLParameter = (!string.IsNullOrEmpty(optionalParameter)) ? true : false;
                DateTime currentDate = DateTime.Now;

                List<string> lastSevenDate = new List<string>();
                List<CurrentTime> lstTime = new List<CurrentTime>();

                for (int i = 1; i <= 7; i++)
                {
                    data data = new data();
                    CurrentTime time = new CurrentTime();

                    data.Day = i +". " + currentDate.AddDays(+i).DayOfWeek.ToString();
                    lstData.Add(data);

                    time.TimeOfDay = currentDate.ToString("HH:mm:ss tt") + " ." + i;
                    lstTime.Add(time);
                }
                responseData.Days = lstData;
                responseData.TimeOfTheDay = lstTime; // currentDate.TimeOfDay.ToString();

                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, responseData, "application/json");
            }
            catch(Exception ex)
            {

            }
            
            return httpResponseMessage;
        }



        // POST MEthod 
        [HttpPost]
        [Route("SLK/PostWeekDayDetails/{optionalParameter?}")]
        public HttpResponseMessage PostWeekDayDetails([FromBody] RequestPayload request, [FromUri] string optionalParameter = null)
        {
            HttpResponseMessage httpResponseMessage = new HttpResponseMessage();
            List<data> lstData = new List<data>();
            PostResponseData responseData = new PostResponseData();
            try
            {
                responseData.URLParameter = (!string.IsNullOrEmpty(optionalParameter)) ? true : false;
                DateTime currentDate = DateTime.Now;

                List<string> lastSevenDate = new List<string>();
                List<CurrentTime> lstTime = new List<CurrentTime>();

                for (int i = 1; i <= 7; i++)
                {
                    data data = new data();
                    CurrentTime time = new CurrentTime();

                    data.Day = i + ". " + currentDate.AddDays(+i).DayOfWeek.ToString();
                    lstData.Add(data);

                    time.TimeOfDay = currentDate.ToString("HH:mm:ss tt") + " ." + i;
                    lstTime.Add(time);
                }
                responseData.Days = lstData;
                responseData.TimeOfTheDay = lstTime; // currentDate.TimeOfDay.ToString();

                List<Dictionary<string, string>> lstkeyValuePairs = new List<Dictionary<string, string>>();
                for (int j= 0; j < request.dateRequests.Count; j++)
                {
                    Dictionary<string, string> keyValuePairs = new Dictionary<string, string>();
                    keyValuePairs.Add("InputDate[" + j + "]- ", request.dateRequests[j].Dates);

                    lstkeyValuePairs.Add(keyValuePairs);
                }
                responseData.InputDates = lstkeyValuePairs;
                
            }
            catch (Exception ex)
            {

            }
            httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, responseData, "application/json");
            return httpResponseMessage;
        }

        public class PostResponseData
        {
            public List<Dictionary<string, string>> InputDates { get; set; }
            public List<data> Days { get; set; }
            public bool URLParameter { get; set; }
            public List<CurrentTime> TimeOfTheDay { get; set; }
            
        }

        public class inputDates
        {
            public string Dates { get; set; }
        }
        public class RequestPayload
        {
            public List<DateRequest> dateRequests { get; set; }
        }

        public class DateRequest
        {
            public string Dates { get; set; }
        }
    }
}
